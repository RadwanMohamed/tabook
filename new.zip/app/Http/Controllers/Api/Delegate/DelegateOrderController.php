<?php

namespace App\Http\Controllers\Api\Delegate;

use App\Http\Controllers\ApiController;
use App\Order;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DelegateOrderController extends ApiController
{
    public function getPreviousOrders()
    {
        $user = User::find(\request()->user()->id);
        if ($user->role != User::DELEGATE)
            return $this->errorResponse("this feature is exist only for delegates",422);
        $orders = Order::where([["delegate_id",\request()->user()->id],["status",Order::DONE]])->get();
        return $this->showAll("orders",$orders);
    }
    public function getMyOrders()
    {
        $user = User::find(\request()->user()->id);
        if ($user->role != User::DELEGATE)
            return $this->errorResponse("this feature is exist only for delegates",422);
        $orders = Order::where([["delegate_id",\request()->user()->id],["status",Order::NEW]])->get();
        return $this->showAll("orders",$orders);
    }

}
