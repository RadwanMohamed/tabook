<?php

namespace App\Http\Controllers\Api\Service;

use App\Service;
use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;

class ServiceController extends ApiController
{
    public function index()
    {
        $services = Service::all();
        return $this->showAll("serices",$services);
    }
    public function show(Service $service)
    {
        return $this->showOne("service",$service);
    }
}
