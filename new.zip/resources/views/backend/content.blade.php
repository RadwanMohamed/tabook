<div class="row">
    <div class="col-lg-12 col-md-12 col-xs-12">
        <div class="card">
            <div class="card-header no-border-bottom">
            </div>
            <div class="card-body collapse in">
                <div class="card-block">

                </div>
            </div>
        </div>
    </div>
</div>
